package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping("/hello")
	public ModelAndView sayHello()
	{
		String str="Hello Welcome To Spring MVC";
		ModelAndView model=new ModelAndView("success","message",str);
		/*model.setViewName();
		model.addObject("message", str);*/
		return(model);
	}
	
	@RequestMapping("/hello1")
	public String sayHello1(Model model)
	{
		model.addAttribute("message","Hello From HELLO");
		return("success");
	}
}
